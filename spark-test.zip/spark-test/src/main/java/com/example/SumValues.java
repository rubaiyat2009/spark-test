package com.example;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.SparkConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SumValues {
    private static final Logger logger = LoggerFactory.getLogger(SumValues.class);

    public static void main(String[] args) {
        logger.info("Starting SumValues application");

        if (args.length != 2) {
            logger.error("Usage: SumValues <input path> <output path>");
            System.exit(-1);
        }

        SparkConf conf = new SparkConf().setAppName("Sum Values");
        JavaSparkContext sc = new JavaSparkContext(conf);

        try {
            logger.info("Input path: {}", args[0]);
            logger.info("Output path: {}", args[1]);

            JavaRDD<String> lines = sc.textFile(args[0]);
            int sum = lines.map(Integer::parseInt).reduce(Integer::sum);
            logger.info("Sum of values: {}", sum);

            sc.parallelize(java.util.Collections.singletonList(sum)).saveAsTextFile(args[1]);
        } catch (Exception e) {
            logger.error("An error occurred while processing the data", e);
        } finally {
            sc.stop();
            logger.info("SumValues application finished");
        }
    }
}
